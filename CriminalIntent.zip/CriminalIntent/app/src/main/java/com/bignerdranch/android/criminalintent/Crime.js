// package com.bignerdranch.android.criminalintent

// import java.util.*

// data class Crime(val id: UUID = UUID.randomUUID(),
//                  var title: String = "",
//                  var date: Date = Date(),
//                  var isSolved: Boolean = false)
       
                 
                 
package com.bignerdranch.android.shelterlocation

import java.util.*

data class Shelter(var name: String = "",
                   var address: String = "",
                   var suburb: String = "",
                   var phone: String = "",
                   var email: String = "")